from flask import Blueprint, jsonify
from lib.db import query, execute

users_bp = Blueprint("users", __name__)

@users_bp.route("", methods=["GET"])
def get_users():
    return jsonify(query(
        "SELECT id, name, email, phone, role FROM users ORDER BY id DESC"
    ))

@users_bp.route("/<int:uid>", methods=["DELETE"])
def delete_user(uid):
    execute("DELETE FROM users WHERE id=%s", (uid,))
    return jsonify({"success": True})
